ALTER TABLE "order" ALTER COLUMN provider SET DEFAULT 'manual_transfer';
