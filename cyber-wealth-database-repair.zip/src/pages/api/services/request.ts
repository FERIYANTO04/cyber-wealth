import type { NextApiRequest, NextApiResponse } from 'next'
import { z } from 'zod'
import { and, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { activity, serviceRequests, services } from '@/lib/db/schema'
import { serviceRequestCode } from '@/lib/services'

const Body = z.object({
  slug: z.string().trim().min(1).max(120),
  name: z.string().trim().min(2, 'Nama minimal 2 karakter').max(120),
  email: z.string().trim().toLowerCase().email('Alamat email tidak valid').max(200),
  company: z.string().trim().max(120).optional(),
  market: z.enum(['Indonesia', 'International']).default('Indonesia'),
  brief: z.string().trim().min(20, 'Ceritakan kebutuhan Anda minimal 20 karakter').max(3000),
  budgetIdr: z.coerce.number().int().min(0).max(10_000_000_000).optional(),
})

// Best effort per instance; the real guard is the brief's length limit and the
// owner reviewing every request before anything is promised.
const hits = new Map<string, { n: number; at: number }>()
function limited(ip: string): boolean {
  const now = Date.now()
  const entry = hits.get(ip)
  if (!entry || now - entry.at > 60_000) {
    hits.set(ip, { n: 1, at: now })
    if (hits.size > 5000) hits.clear()
    return false
  }
  entry.n += 1
  return entry.n > 5
}

/** A prospective client's brief. This is a lead, never revenue. */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Metode tidak diizinkan' })

  const ip = String(req.headers['x-forwarded-for'] ?? req.socket.remoteAddress ?? 'unknown').split(',')[0]
  if (limited(ip)) return res.status(429).json({ error: 'Terlalu banyak permintaan. Tunggu sebentar, lalu coba lagi.' })

  const parsed = Body.safeParse(req.body)
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues[0]?.message ?? 'Data permintaan tidak valid.' })
  }

  const [service] = await db
    .select()
    .from(services)
    .where(and(eq(services.slug, parsed.data.slug), eq(services.status, 'published')))
    .limit(1)
  if (!service) return res.status(404).json({ error: 'Layanan tidak ditemukan atau tidak sedang ditawarkan.' })

  const [row] = await db
    .insert(serviceRequests)
    .values({
      code: serviceRequestCode(),
      serviceId: service.id,
      serviceName: service.name,
      name: parsed.data.name,
      email: parsed.data.email,
      company: parsed.data.company || null,
      market: parsed.data.market,
      brief: parsed.data.brief,
      budgetIdr: parsed.data.budgetIdr ?? null,
      status: 'new',
    })
    .returning()

  await db.insert(activity).values({
    actor: 'system',
    action: 'Permintaan jasa masuk',
    detail: `${row.code} — ${row.serviceName} dari ${row.name} (${row.email}). Belum menjadi penjualan.`,
    dataSource: 'live',
  })

  return res.status(201).json({ ok: true, code: row.code })
}
